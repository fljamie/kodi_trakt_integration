#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import requests
import json
import time

def log(msg):
    xbmc.log('[Trakt Authorize] {}'.format(msg), xbmc.LOGINFO)

def authorize_trakt():
    """Handle Trakt authorization"""
    # CRITICAL: Wait 3 seconds for Kodi to auto-flush settings to disk
    # This allows settings dialog to remain open while ensuring we read
    # the latest Client ID and Client Secret values
    log('Waiting for settings to flush...')
    time.sleep(3)
    log('Settings flush complete, starting authorization...')
    
    # CRITICAL: Create fresh addon instance to ensure settings can be saved properly
    ADDON = xbmcaddon.Addon('plugin.video.traktsearch')
    
    client_id = ADDON.getSetting('client_id')
    client_secret = ADDON.getSetting('client_secret')
    
    log('=== AUTHORIZATION STARTED ===')
    log('Client ID present: {}'.format(bool(client_id)))
    log('Client Secret present: {}'.format(bool(client_secret)))
    
    if not client_id or not client_secret:
        xbmcgui.Dialog().ok('Configuration Required', 
                           'Please enter your Trakt Client ID and Client Secret in the settings first.')
        return
    
    # Get device code
    headers = {
        'Content-Type': 'application/json'
    }
    data = {'client_id': client_id}
    
    log('Requesting device code from Trakt...')
    try:
        response = requests.post(
            'https://api.trakt.tv/oauth/device/code',
            json=data,
            headers=headers,
            timeout=10
        )
        log('Device code response status: {}'.format(response.status_code))
        
        if response.status_code != 200:
            log('ERROR: Failed to get device code. Response: {}'.format(response.text))
            xbmcgui.Dialog().ok('Error', 'Failed to get device code from Trakt')
            return
        
        device_code_data = response.json()
        log('Device code received successfully')
    except Exception as e:
        log('ERROR: Exception getting device code: {}'.format(str(e)))
        xbmcgui.Dialog().ok('Error', 'Failed to connect to Trakt: {}'.format(str(e)))
        return
    
    device_code = device_code_data.get('device_code')
    user_code = device_code_data.get('user_code')
    verification_url = device_code_data.get('verification_url', 'https://trakt.tv/activate')
    interval = device_code_data.get('interval', 5)
    expires_in = device_code_data.get('expires_in', 600)
    
    log('User code: {}'.format(user_code))
    log('Verification URL: {}'.format(verification_url))
    
    # Show authorization dialog - user completes authorization BEFORE clicking OK
    dialog = xbmcgui.Dialog()
    dialog.ok('Authorize Trakt',
             'Go to: [B]{}[/B][CR][CR]Enter code: [B]{}[/B][CR][CR]Complete authorization, then click OK'.format(verification_url, user_code))
    
    # NOW start polling (after user clicked OK, meaning they completed authorization)
    progress = xbmcgui.DialogProgress()
    progress.create('Authorizing Trakt', 'Verifying authorization with Trakt...')
    
    max_attempts = int(expires_in / interval)
    attempt = 0
    
    log('Starting polling for token (max {} attempts)'.format(max_attempts))
    
    while attempt < max_attempts:
        if progress.iscanceled():
            log('User canceled authorization')
            progress.close()
            return
        
        percent = int((attempt / max_attempts) * 100)
        progress.update(percent, 'Checking authorization status... (Attempt {}/{})'.format(attempt + 1, max_attempts))
        
        poll_data = {
            'code': device_code,
            'client_id': client_id,
            'client_secret': client_secret
        }
        
        try:
            log('Polling for token (attempt {})'.format(attempt + 1))
            response = requests.post(
                'https://api.trakt.tv/oauth/device/token',
                json=poll_data,
                headers=headers,
                timeout=10
            )
            log('Poll response status: {}'.format(response.status_code))
            
            if response.status_code == 200:
                token_data = response.json()
                access_token = token_data.get('access_token')
                
                if access_token:
                    log('=== AUTHORIZATION SUCCESSFUL ===')
                    log('Access token received (length: {})'.format(len(access_token)))
                    
                    # BYPASS setSetting() - write directly to settings.xml file
                    log('Saving access token directly to settings file...')
                    
                    import os
                    import time
                    
                    # Get settings file path
                    addon_data_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.traktsearch/')
                    settings_file = os.path.join(addon_data_path, 'settings.xml')
                    
                    log('Settings file path: {}'.format(settings_file))
                    
                    try:
                        # Ensure directory exists
                        if not os.path.exists(addon_data_path):
                            os.makedirs(addon_data_path)
                            log('Created addon data directory')
                        
                        # Read existing settings or create new
                        if os.path.exists(settings_file):
                            with open(settings_file, 'r') as f:
                                content = f.read()
                            log('Read existing settings file ({} bytes)'.format(len(content)))
                        else:
                            # Create minimal settings structure
                            content = '<settings version="2">\n</settings>'
                            log('Creating new settings file')
                        
                        # Check if access_token already exists
                        if '<setting id="access_token"' in content:
                            # Update existing access_token
                            import re
                            # Match: <setting id="access_token">old_value</setting>
                            # Or: <setting id="access_token" ... >old_value</setting>
                            pattern = r'<setting id="access_token"[^>]*>.*?</setting>'
                            replacement = '<setting id="access_token">{}</setting>'.format(access_token)
                            content = re.sub(pattern, replacement, content)
                            log('Updated existing access_token in settings')
                        else:
                            # Add new access_token before </settings>
                            new_line = '    <setting id="access_token">{}</setting>\n'.format(access_token)
                            content = content.replace('</settings>', new_line + '</settings>')
                            log('Added new access_token to settings')
                        
                        # Write back to file
                        with open(settings_file, 'w') as f:
                            f.write(content)
                        log('Wrote settings file successfully')
                        
                        # Verify file was written
                        time.sleep(0.5)
                        if os.path.exists(settings_file):
                            with open(settings_file, 'r') as f:
                                verify_content = f.read()
                            if access_token in verify_content:
                                log('SUCCESS: Token verified in settings file!')
                                log('Settings file size: {} bytes'.format(len(verify_content)))
                            else:
                                log('WARNING: Token not found in settings file after write')
                        
                        # CRITICAL: Also update Kodi's in-memory cache via setSetting()
                        # This ensures fetch_lists.py can read the token immediately
                        log('Updating Kodi settings cache with setSetting()...')
                        ADDON.setSetting('access_token', access_token)
                        log('setSetting() completed - token now in both file and cache')
                        
                        # Give Kodi extra time to flush settings to disk
                        time.sleep(2)
                        log('Waited for settings flush')
                        
                    except Exception as e:
                        log('ERROR writing settings file: {}'.format(str(e)))
                        import traceback
                        log('Traceback: {}'.format(traceback.format_exc()))
                    
                    progress.close()
                    xbmcgui.Dialog().ok('Success', 'Trakt authorization successful![CR][CR]Access token saved directly to file.[CR][CR]You can now search and add content to your Trakt lists!')
                    return
            elif response.status_code == 400:
                # This is expected while waiting for user to authorize
                log('Waiting for user to authorize (400 response is normal)')
            else:
                log('Unexpected response: {}'.format(response.text[:200]))
        except Exception as e:
            log('ERROR during polling: {}'.format(str(e)))
        
        xbmc.sleep(interval * 1000)
        attempt += 1
    
    log('Authorization timed out')
    progress.close()
    xbmcgui.Dialog().ok('Timeout', 'Authorization timed out. Please try again.')

if __name__ == '__main__':
    authorize_trakt()
