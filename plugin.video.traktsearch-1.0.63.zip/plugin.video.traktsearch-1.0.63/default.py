#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests
try:
    from urllib.parse import urlencode, parse_qsl
except ImportError:
    from urlparse import parse_qsl
    from urllib import urlencode
import json

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

handle = int(sys.argv[1])

class TraktAPI:
    def __init__(self):
        # CRITICAL: Always create a fresh addon instance to get latest settings
        # This ensures we pick up tokens saved by authorize.py
        addon = xbmcaddon.Addon('plugin.video.traktsearch')
        
        self.client_id = addon.getSetting('client_id')
        self.client_secret = addon.getSetting('client_secret')
        self.access_token = addon.getSetting('access_token')
        self.base_url = 'https://api.trakt.tv'
        
        # Log initialization for debugging
        xbmc.log('[Trakt Search] === TraktAPI INITIALIZED ===', xbmc.LOGINFO)
        xbmc.log('[Trakt Search] Addon ID: plugin.video.traktsearch', xbmc.LOGINFO)
        xbmc.log('[Trakt Search] Client ID present: {}'.format(bool(self.client_id)), xbmc.LOGINFO)
        xbmc.log('[Trakt Search] Client ID length: {}'.format(len(self.client_id) if self.client_id else 0), xbmc.LOGINFO)
        xbmc.log('[Trakt Search] Access token present: {}'.format(bool(self.access_token)), xbmc.LOGINFO)
        if self.access_token:
            xbmc.log('[Trakt Search] Access token length: {}'.format(len(self.access_token)), xbmc.LOGINFO)
            xbmc.log('[Trakt Search] Access token first 10 chars: {}...'.format(self.access_token[:10]), xbmc.LOGINFO)
        else:
            xbmc.log('[Trakt Search] *** WARNING: NO ACCESS TOKEN FOUND! ***', xbmc.LOGWARNING)
            xbmc.log('[Trakt Search] User needs to authorize with Trakt in settings.', xbmc.LOGWARNING)
        
    def make_request(self, endpoint, method='GET', data=None, auth_required=True):
        url = self.base_url + endpoint
        headers = {
            'Content-Type': 'application/json',
            'trakt-api-version': '2',
            'trakt-api-key': self.client_id
        }
        
        if auth_required and self.access_token:
            headers['Authorization'] = 'Bearer ' + self.access_token
        
        xbmc.log('[Trakt Search] Request: {} {}'.format(method, url), xbmc.LOGDEBUG)
        if data:
            xbmc.log('[Trakt Search] Request data: {}'.format(json.dumps(data)), xbmc.LOGDEBUG)
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, headers=headers, json=data, timeout=10)
            elif method == 'DELETE':
                response = requests.delete(url, headers=headers, json=data, timeout=10)
            
            xbmc.log('[Trakt Search] Response: {} - {}'.format(response.status_code, response.text[:200] if response.text else 'empty'), xbmc.LOGDEBUG)
            
            if response.status_code in [200, 201, 204]:
                if response.text:
                    return response.json()
                return {'success': True}
            else:
                xbmc.log('[Trakt Search] HTTP Error {}: {}'.format(response.status_code, response.text), xbmc.LOGERROR)
                return None
        except Exception as e:
            xbmc.log('[Trakt Search] Error: {}'.format(str(e)), xbmc.LOGERROR)
            import traceback
            xbmc.log('[Trakt Search] Traceback: {}'.format(traceback.format_exc()), xbmc.LOGERROR)
            return None
    
    def get_device_code(self):
        data = {'client_id': self.client_id}
        return self.make_request('/oauth/device/code', 'POST', data, auth_required=False)
    
    def poll_for_token(self, device_code):
        data = {
            'code': device_code,
            'client_id': self.client_id,
            'client_secret': self.client_secret
        }
        return self.make_request('/oauth/device/token', 'POST', data, auth_required=False)
    
    def get_user_settings(self):
        """Get user settings including username"""
        return self.make_request('/users/settings', auth_required=True)
    
    def get_user_lists(self, username):
        """Get all lists for a user"""
        endpoint = '/users/{}/lists'.format(username)
        return self.make_request(endpoint, auth_required=True)
    
    def add_to_list(self, username, list_slug, item_type, item_id):
        endpoint = '/users/{}/lists/{}/items'.format(username, list_slug)
        
        if item_type == 'movie':
            data = {
                'movies': [{'ids': {'tmdb': item_id}}]
            }
        else:  # tv show
            data = {
                'shows': [{'ids': {'tmdb': item_id}}]
            }
        
        return self.make_request(endpoint, 'POST', data, auth_required=True)

class TMDBAPI:
    def __init__(self):
        self.api_key = ADDON.getSetting('tmdb_api_key')
        self.base_url = 'https://api.themoviedb.org/3'
        self.image_base = 'https://image.tmdb.org/t/p/w500'
        
    def make_request(self, endpoint, params=None):
        url = self.base_url + endpoint
        
        if params is None:
            params = {}
        params['api_key'] = self.api_key
        
        try:
            xbmc.log('[Trakt Search] TMDB Request: {}'.format(url), xbmc.LOGDEBUG)
            xbmc.log('[Trakt Search] TMDB Params: {}'.format(params), xbmc.LOGDEBUG)
            response = requests.get(url, params=params, timeout=10)
            xbmc.log('[Trakt Search] TMDB Status: {}'.format(response.status_code), xbmc.LOGDEBUG)
            
            if response.status_code == 200:
                return response.json()
            else:
                xbmc.log('[Trakt Search] TMDB Error: {}'.format(response.status_code), xbmc.LOGERROR)
                xbmc.log('[Trakt Search] TMDB Response: {}'.format(response.text[:200]), xbmc.LOGERROR)
                return None
        except Exception as e:
            xbmc.log('[Trakt Search] TMDB Error: {}'.format(str(e)), xbmc.LOGERROR)
            return None
    
    def search_movies(self, query):
        endpoint = '/search/movie'
        params = {'query': query}
        return self.make_request(endpoint, params)
    
    def search_tv(self, query):
        endpoint = '/search/tv'
        params = {'query': query}
        return self.make_request(endpoint, params)
    
    def search_person(self, query):
        endpoint = '/search/person'
        params = {'query': query}
        return self.make_request(endpoint, params)
    
    def get_person_credits(self, person_id):
        endpoint = '/person/{}/combined_credits'.format(person_id)
        return self.make_request(endpoint)

def get_url(**kwargs):
    return '{}?{}'.format(sys.argv[0], urlencode(kwargs))

def authorize_trakt():
    """Handle Trakt authorization"""
    trakt = TraktAPI()
    
    if not trakt.client_id or not trakt.client_secret:
        xbmcgui.Dialog().ok('Configuration Required', 
                           'Please configure your Trakt Client ID and Client Secret in the add-on settings first.')
        ADDON.openSettings()
        return
    
    device_code_data = trakt.get_device_code()
    if not device_code_data:
        xbmcgui.Dialog().ok('Error', 'Failed to get device code from Trakt')
        return
    
    device_code = device_code_data.get('device_code')
    user_code = device_code_data.get('user_code')
    verification_url = device_code_data.get('verification_url', 'https://trakt.tv/activate')
    interval = device_code_data.get('interval', 5)
    expires_in = device_code_data.get('expires_in', 600)
    
    dialog = xbmcgui.Dialog()
    dialog.ok('Authorize Trakt',
             'Go to: [B]{}[/B][CR][CR]Enter code: [B]{}[/B][CR][CR]Then click OK'.format(verification_url, user_code))
    
    progress = xbmcgui.DialogProgress()
    progress.create('Authorizing Trakt', 'Waiting for authorization...')
    
    max_attempts = expires_in / interval
    attempt = 0
    
    while attempt < max_attempts:
        if progress.iscanceled():
            progress.close()
            return
        
        percent = int((attempt / max_attempts) * 100)
        progress.update(percent, 'Checking authorization status...')
        
        token_data = trakt.poll_for_token(device_code)
        if token_data and 'access_token' in token_data:
            ADDON.setSetting('access_token', token_data['access_token'])
            progress.close()
            xbmcgui.Dialog().ok('Success', 'Trakt authorization successful![CR][CR]You can now fetch your lists and start adding content.')
            return
        
        xbmc.sleep(interval * 1000)
        attempt += 1
    
    progress.close()
    xbmcgui.Dialog().ok('Timeout', 'Authorization timed out. Please try again.')

def fetch_user_lists():
    """Fetch and display user's Trakt lists"""
    trakt = TraktAPI()
    
    if not trakt.access_token:
        xbmcgui.Dialog().ok('Authorization Required', 
                           'Please authorize with Trakt first.')
        return
    
    # Get username
    user_settings = trakt.get_user_settings()
    if not user_settings or 'user' not in user_settings:
        xbmcgui.Dialog().ok('Error', 'Failed to get user information from Trakt.')
        return
    
    username = user_settings['user']['ids']['slug']
    
    # Get user's lists
    lists = trakt.get_user_lists(username)
    if not lists:
        xbmcgui.Dialog().ok('No Lists Found', 'No custom lists found in your Trakt account.[CR][CR]Create lists at https://trakt.tv first.')
        return
    
    # Format list information
    list_info = []
    list_info.append('[B]YOUR TRAKT LISTS:[/B]')
    list_info.append('')
    for lst in lists:
        name = lst.get('name', 'Unknown')
        slug = lst.get('ids', {}).get('slug', 'unknown')
        item_count = lst.get('item_count', 0)
        list_info.append('[B]{}[/B]'.format(name))
        list_info.append('  Slug: [COLOR cyan]{}[/COLOR]'.format(slug))
        list_info.append('  Items: {}'.format(item_count))
        list_info.append('')
    
    list_info.append('[B]HOW TO USE:[/B]')
    list_info.append('Copy the [COLOR cyan]slug[/COLOR] values above')
    list_info.append('Paste them in Settings:')
    list_info.append('  • TV Shows List Slug')
    list_info.append('  • Movies List Slug')
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer('Your Trakt Lists', '\n'.join(list_info))

def add_to_trakt_list(item_type, item_id, item_name):
    """Add item to appropriate Trakt list"""
    xbmc.log('[Trakt Search] === ADD TO TRAKT LIST ===', xbmc.LOGINFO)
    xbmc.log('[Trakt Search] Item type: {}'.format(item_type), xbmc.LOGINFO)
    xbmc.log('[Trakt Search] Item ID: {}'.format(item_id), xbmc.LOGINFO)
    xbmc.log('[Trakt Search] Item name: {}'.format(item_name), xbmc.LOGINFO)
    
    # Show confirmation dialog
    dialog = xbmcgui.Dialog()
    confirmed = dialog.yesno(
        'Add to Trakt Watchlist?',
        'Would you like to add [B]{}[/B] to your Trakt watchlist?'.format(item_name),
        nolabel='Cancel',
        yeslabel='Add'
    )
    
    if not confirmed:
        xbmc.log('[Trakt Search] User cancelled addition', xbmc.LOGINFO)
        return
    
    trakt = TraktAPI()
    
    xbmc.log('[Trakt Search] Access token present: {}'.format(bool(trakt.access_token)), xbmc.LOGINFO)
    if trakt.access_token:
        xbmc.log('[Trakt Search] Access token length: {}'.format(len(trakt.access_token)), xbmc.LOGINFO)
    
    if not trakt.access_token:
        xbmc.log('[Trakt Search] ERROR: No access token found!', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Authorization Required', 
                           'Please authorize with Trakt first.')
        return
    
    # Get username
    xbmc.log('[Trakt Search] Getting user settings...', xbmc.LOGINFO)
    user_settings = trakt.get_user_settings()
    xbmc.log('[Trakt Search] User settings response: {}'.format(user_settings), xbmc.LOGDEBUG)
    
    if not user_settings or 'user' not in user_settings:
        xbmc.log('[Trakt Search] ERROR: Failed to get user information', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', 'Failed to get user information.[CR][CR]Your Trakt authorization may have expired. Please re-authorize.')
        return
    
    username = user_settings['user']['ids']['slug']
    xbmc.log('[Trakt Search] Username: {}'.format(username), xbmc.LOGINFO)
    
    # Determine which list to use
    if item_type == 'movie':
        list_slug = ADDON.getSetting('movie_list_slug') or 'movies'
        list_display = 'Movies'
    else:  # tv show
        list_slug = ADDON.getSetting('tv_list_slug') or 'newshows'
        list_display = 'TV Shows'
    
    xbmc.log('[Trakt Search] Using list slug: {}'.format(list_slug), xbmc.LOGINFO)
    
    # Add to list
    xbmc.log('[Trakt Search] Attempting to add to Trakt list...', xbmc.LOGINFO)
    result = trakt.add_to_list(username, list_slug, item_type, item_id)
    xbmc.log('[Trakt Search] Add to list result: {}'.format(result), xbmc.LOGINFO)
    
    if result:
        xbmc.log('[Trakt Search] SUCCESS: Item added to list!', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'Successfully Added',
            '"{}" added to your {} list'.format(item_name, list_display),
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    else:
        xbmcgui.Dialog().notification(
            'Failed to Add',
            'Could not add to Trakt list',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )

def show_main_menu():
    """Show main menu"""
    xbmcplugin.setContent(handle, 'files')
    
    # Search Movies
    item = xbmcgui.ListItem(label='Search Movies')
    item.setArt({'icon': 'DefaultVideo.png'})
    url = get_url(action='search_movies')
    xbmcplugin.addDirectoryItem(handle, url, item, True)
    
    # Search TV Shows
    item = xbmcgui.ListItem(label='Search TV Shows')
    item.setArt({'icon': 'DefaultTVShows.png'})
    url = get_url(action='search_tv')
    xbmcplugin.addDirectoryItem(handle, url, item, True)
    
    # Search Actors
    item = xbmcgui.ListItem(label='Search Actors')
    item.setArt({'icon': 'DefaultActor.png'})
    url = get_url(action='search_person')
    xbmcplugin.addDirectoryItem(handle, url, item, True)
    
    xbmcplugin.endOfDirectory(handle)

def show_search_movies():
    """Search for movies"""
    # Check TMDB API key is set
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        xbmcgui.Dialog().ok('TMDB API Key Required', 
                           'Please add your TMDB API Key in Settings → TMDB Configuration')
        ADDON.openSettings()
        return
    
    keyboard = xbmc.Keyboard('', 'Search for Movies')
    keyboard.doModal()
    
    if not keyboard.isConfirmed():
        return
    
    query = keyboard.getText()
    if not query:
        return
    
    tmdb = TMDBAPI()
    results = tmdb.search_movies(query)
    
    if not results or 'results' not in results:
        xbmcgui.Dialog().notification('No Results', 'No movies found', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    
    xbmcplugin.setContent(handle, 'movies')
    
    for movie in results['results']:
        title = movie.get('title', 'Unknown')
        year = movie.get('release_date', '')[:4]
        overview = movie.get('overview', 'No description available')
        poster = movie.get('poster_path')
        tmdb_id = movie.get('id')
        
        label = '{} ({})'.format(title, year) if year else title
        
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'movie'
        })
        
        if poster:
            poster_url = 'https://image.tmdb.org/t/p/w500{}'.format(poster)
            item.setArt({'poster': poster_url, 'icon': poster_url})
        
        url = get_url(action='add_movie', tmdb_id=tmdb_id, title=title)
        xbmcplugin.addDirectoryItem(handle, url, item, False)
    
    xbmcplugin.endOfDirectory(handle)

def show_search_tv():
    """Search for TV shows"""
    # Check TMDB API key is set
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        xbmcgui.Dialog().ok('TMDB API Key Required', 
                           'Please add your TMDB API Key in Settings → TMDB Configuration')
        ADDON.openSettings()
        return
    
    keyboard = xbmc.Keyboard('', 'Search for TV Shows')
    keyboard.doModal()
    
    if not keyboard.isConfirmed():
        return
    
    query = keyboard.getText()
    if not query:
        return
    
    tmdb = TMDBAPI()
    results = tmdb.search_tv(query)
    
    if not results or 'results' not in results:
        xbmcgui.Dialog().notification('No Results', 'No TV shows found', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    
    xbmcplugin.setContent(handle, 'tvshows')
    
    for show in results['results']:
        title = show.get('name', 'Unknown')
        year = show.get('first_air_date', '')[:4]
        overview = show.get('overview', 'No description available')
        poster = show.get('poster_path')
        tmdb_id = show.get('id')
        
        label = '{} ({})'.format(title, year) if year else title
        
        item = xbmcgui.ListItem(label=label)
        item.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'tvshow'
        })
        
        if poster:
            poster_url = 'https://image.tmdb.org/t/p/w500{}'.format(poster)
            item.setArt({'poster': poster_url, 'icon': poster_url})
        
        url = get_url(action='add_show', tmdb_id=tmdb_id, title=title)
        xbmcplugin.addDirectoryItem(handle, url, item, False)
    
    xbmcplugin.endOfDirectory(handle)

def show_search_person():
    """Search for actors/people"""
    # Check TMDB API key is set
    tmdb_key = ADDON.getSetting('tmdb_api_key')
    if not tmdb_key:
        xbmcgui.Dialog().ok('TMDB API Key Required', 
                           'Please add your TMDB API Key in Settings → TMDB Configuration')
        ADDON.openSettings()
        return
    
    keyboard = xbmc.Keyboard('', 'Search for Actors')
    keyboard.doModal()
    
    if not keyboard.isConfirmed():
        return
    
    query = keyboard.getText()
    if not query:
        return
    
    tmdb = TMDBAPI()
    results = tmdb.search_person(query)
    
    if not results or 'results' not in results:
        xbmcgui.Dialog().notification('No Results', 'No actors found', xbmcgui.NOTIFICATION_INFO, 3000)
        return
    
    xbmcplugin.setContent(handle, 'artists')
    
    for person in results['results']:
        name = person.get('name', 'Unknown')
        known_for = person.get('known_for_department', 'Acting')
        profile = person.get('profile_path')
        person_id = person.get('id')
        
        item = xbmcgui.ListItem(label=name)
        item.setInfo('video', {
            'title': name,
            'plot': 'Known for: {}'.format(known_for)
        })
        
        if profile:
            profile_url = 'https://image.tmdb.org/t/p/w500{}'.format(profile)
            item.setArt({'thumb': profile_url, 'icon': profile_url})
        
        url = get_url(action='show_filmography', person_id=person_id, name=name)
        xbmcplugin.addDirectoryItem(handle, url, item, True)
    
    xbmcplugin.endOfDirectory(handle)

def show_filmography(person_id, name):
    """Show actor's filmography"""
    tmdb = TMDBAPI()
    credits = tmdb.get_person_credits(person_id)
    
    if not credits:
        xbmcgui.Dialog().notification('Error', 'Failed to load filmography', xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    
    xbmcplugin.setContent(handle, 'movies')
    
    # Process movies
    for movie in credits.get('cast', []):
        if movie.get('media_type') == 'movie':
            title = movie.get('title', 'Unknown')
            year = movie.get('release_date', '')[:4]
            character = movie.get('character', '')
            overview = movie.get('overview', 'No description available')
            poster = movie.get('poster_path')
            tmdb_id = movie.get('id')
            
            label = '{} ({})'.format(title, year) if year else title
            if character:
                label += ' as {}'.format(character)
            
            item = xbmcgui.ListItem(label=label)
            item.setInfo('video', {
                'title': title,
                'year': int(year) if year else 0,
                'plot': overview,
                'mediatype': 'movie'
            })
            
            if poster:
                poster_url = 'https://image.tmdb.org/t/p/w500{}'.format(poster)
                item.setArt({'poster': poster_url, 'icon': poster_url})
            
            url = get_url(action='add_movie', tmdb_id=tmdb_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, item, False)
    
    # Process TV shows
    for show in credits.get('cast', []):
        if show.get('media_type') == 'tv':
            title = show.get('name', 'Unknown')
            year = show.get('first_air_date', '')[:4]
            character = show.get('character', '')
            overview = show.get('overview', 'No description available')
            poster = show.get('poster_path')
            tmdb_id = show.get('id')
            
            label = '{} ({})'.format(title, year) if year else title
            if character:
                label += ' as {}'.format(character)
            
            item = xbmcgui.ListItem(label=label)
            item.setInfo('video', {
                'title': title,
                'year': int(year) if year else 0,
                'plot': overview,
                'mediatype': 'tvshow'
            })
            
            if poster:
                poster_url = 'https://image.tmdb.org/t/p/w500{}'.format(poster)
                item.setArt({'poster': poster_url, 'icon': poster_url})
            
            url = get_url(action='add_show', tmdb_id=tmdb_id, title=title)
            xbmcplugin.addDirectoryItem(handle, url, item, False)
    
    xbmcplugin.endOfDirectory(handle)

def router(paramstring):
    """Route to appropriate function"""
    params = dict(parse_qsl(paramstring))
    action = params.get('action')
    
    if action is None:
        show_main_menu()
    elif action == 'authorize':
        authorize_trakt()
    elif action == 'fetch_lists':
        fetch_user_lists()
    elif action == 'search_movies':
        show_search_movies()
    elif action == 'search_tv':
        show_search_tv()
    elif action == 'search_person':
        show_search_person()
    elif action == 'show_filmography':
        show_filmography(params['person_id'], params['name'])
    elif action == 'add_movie':
        add_to_trakt_list('movie', params['tmdb_id'], params['title'])
    elif action == 'add_show':
        add_to_trakt_list('show', params['tmdb_id'], params['title'])

if __name__ == '__main__':
    router(sys.argv[2][1:])
