#!/usr/bin/env python
# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import time

try:
    import urllib.request as urllib2
    from urllib.error import HTTPError, URLError
except ImportError:
    import urllib2
    from urllib2 import HTTPError, URLError

def log(msg):
    xbmc.log('[Trakt Fetch Lists] {}'.format(msg), xbmc.LOGINFO)

def make_request(url, headers):
    """Make HTTP request"""
    try:
        req = urllib2.Request(url, headers=headers)
        response = urllib2.urlopen(req, timeout=10)
        return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        log('Error: {}'.format(str(e)))
        return None

def fetch_user_lists():
    """Fetch and display user's Trakt lists"""
    # CRITICAL: Wait 3 seconds for Kodi to auto-flush settings to disk
    # This allows settings dialog to remain open while ensuring we read
    # the latest access_token value
    log('Waiting for settings to flush...')
    time.sleep(3)
    log('Settings flush complete, fetching lists...')
    
    log('=== FETCH LISTS STARTED ===')
    
    # CRITICAL: Create fresh addon instance to get latest settings (including token from authorize.py)
    addon = xbmcaddon.Addon('plugin.video.traktsearch')
    
    client_id = addon.getSetting('client_id')
    access_token = addon.getSetting('access_token')
    
    log('Client ID present: {}'.format(bool(client_id)))
    log('Access token present: {}'.format(bool(access_token)))
    log('Access token length: {}'.format(len(access_token) if access_token else 0))
    
    # FALLBACK: If getSetting() returns empty, try reading directly from XML file
    # This handles cases where Kodi's settings cache hasn't been updated yet
    if not access_token or len(access_token) == 0:
        log('Token empty from getSetting(), attempting direct file read...')
        try:
            import os
            addon_data_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.traktsearch/')
            settings_file = os.path.join(addon_data_path, 'settings.xml')
            log('Checking settings file: {}'.format(settings_file))
            
            if os.path.exists(settings_file):
                log('Settings file exists, reading...')
                with open(settings_file, 'r') as f:
                    content = f.read()
                
                # Parse XML to find access_token
                import xml.etree.ElementTree as ET
                try:
                    root = ET.fromstring(content)
                    for setting in root.findall('.//setting[@id="access_token"]'):
                        file_token = setting.text
                        if file_token:
                            log('Found token in file! Length: {}'.format(len(file_token)))
                            access_token = file_token
                            break
                except ET.ParseError as e:
                    log('XML parse error: {}'.format(str(e)))
            else:
                log('Settings file does not exist')
        except Exception as e:
            log('ERROR reading token from file: {}'.format(str(e)))
            import traceback
            log('Traceback: {}'.format(traceback.format_exc()))
    
    log('Final access token present: {}'.format(bool(access_token)))
    log('Final access token length: {}'.format(len(access_token) if access_token else 0))
    
    if not access_token:
        xbmcgui.Dialog().ok('Authorization Required', 
                           'Please authorize with Trakt first using the "Authorize with Trakt" button.')
        return
    
    # Get user settings to get username
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': client_id,
        'Authorization': 'Bearer ' + access_token
    }
    
    user_settings = make_request('https://api.trakt.tv/users/settings', headers)
    
    if not user_settings or 'user' not in user_settings:
        xbmcgui.Dialog().ok('Error', 'Failed to get user information from Trakt.[CR][CR]Please try authorizing again.')
        return
    
    username = user_settings['user']['ids']['slug']
    
    # Get user's lists
    lists_url = 'https://api.trakt.tv/users/{}/lists'.format(username)
    lists = make_request(lists_url, headers)
    
    if not lists:
        xbmcgui.Dialog().ok('No Lists Found', 'No custom lists found in your Trakt account.[CR][CR]Create lists at https://trakt.tv first.')
        return
    
    # Format list information
    list_info = []
    list_info.append('[B]YOUR TRAKT LISTS:[/B]')
    list_info.append('')
    
    for lst in lists:
        name = lst.get('name', 'Unknown')
        slug = lst.get('ids', {}).get('slug', 'unknown')
        item_count = lst.get('item_count', 0)
        
        list_info.append('[B]{}[/B]'.format(name))
        list_info.append('  List Name: [COLOR cyan]{}[/COLOR]'.format(slug))
        list_info.append('  Items: {}'.format(item_count))
        list_info.append('')
    
    list_info.append('[B]HOW TO USE:[/B]')
    list_info.append('Copy the [COLOR cyan]List Name[/COLOR] values above')
    list_info.append('Paste them in Settings:')
    list_info.append('  • TV Show List Name')
    list_info.append('  • Movie List Name')
    list_info.append('')
    list_info.append('Example: If your list name is "newshows",')
    list_info.append('paste "newshows" in TV Show List Name field.')
    
    # Display in text viewer
    xbmcgui.Dialog().textviewer('Your Trakt Lists', '\n'.join(list_info))

if __name__ == '__main__':
    fetch_user_lists()
